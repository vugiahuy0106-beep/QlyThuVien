import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Palette,
  X,
  Check,
  Sparkles,
  Sliders,
  Image as ImageIcon,
  Eye,
  RotateCcw,
  Zap,
} from 'lucide-react';

export interface BackgroundConfig {
  id: string;
  name: string;
  category: 'image' | 'gradient' | 'minimal';
  imageSrc?: string;
  gradientClass?: string;
  description: string;
  tag: string;
}

export const BACKGROUND_PRESETS: BackgroundConfig[] = [
  {
    id: 'clean_library',
    name: 'Thư Viện Số Hiện Đại',
    category: 'image',
    imageSrc: '/src/assets/images/clean_library_hall_1790585896239.jpg',
    description: 'Không gian sảnh thư viện đại học tối tân, ánh sáng dịu, tạo cảm giác học thuật cao cấp.',
    tag: 'Khuyên Dùng · Chuẩn Đồ Án',
  },
  {
    id: 'academic_wood',
    name: 'Hàn Lâm Sang Trọng',
    category: 'image',
    imageSrc: '/src/assets/images/library_modern_academic_1790582992376.jpg',
    description: 'Tone màu gỗ ấm cúng, giá sách đồ sộ, phong cách thư viện nghiên cứu truyền thống kết hợp hiện đại.',
    tag: 'Hàn Lâm · Chiều Sâu',
  },
  {
    id: 'student_study',
    name: 'Khu Nghiên Cứu Sinh Viên',
    category: 'image',
    imageSrc: '/src/assets/images/student_study_zone_1790585118364.jpg',
    description: 'Không gian mở tràn ngập năng lượng sinh viên học nhóm và tra cứu học liệu số.',
    tag: 'Năng Động · Campus',
  },
  {
    id: 'circulation_hub',
    name: 'Quầy Nghiệp Vụ Lưu Thông',
    category: 'image',
    imageSrc: '/src/assets/images/circulation_counter_1790585099229.jpg',
    description: 'Góc nhìn nghiệp vụ quản lý mượn trả và quầy số hóa thẻ bạn đọc thông minh.',
    tag: 'Nghiệp Vụ Thư Viện',
  },
  {
    id: 'midnight_indigo',
    name: 'Đêm Kỹ Thuật (Midnight Indigo)',
    category: 'gradient',
    gradientClass: 'from-slate-950 via-indigo-950 to-slate-900',
    description: 'Nền tối đậm sâu thẳm với luồng ánh sáng chàm dịu mắt, chống mỏi mắt tuyệt đối khi đọc lâu.',
    tag: 'Zero Chói Mắt · Dark Mode',
  },
  {
    id: 'cyber_slate',
    name: 'Cyber Slate Kỹ Thuật Số',
    category: 'minimal',
    gradientClass: 'from-slate-950 via-slate-900 to-zinc-950',
    description: 'Thiết kế tối giản phong cách công nghệ phần mềm, làm nổi bật sơ đồ kiến trúc và mã nguồn.',
    tag: 'Kỹ Thuật · Sắc Nét',
  },
];

interface BackgroundCustomizerProps {
  isOpen: boolean;
  onClose: () => void;
  selectedBgId: string;
  onSelectBg: (id: string) => void;
  overlayDarkness: number;
  onChangeOverlayDarkness: (val: number) => void;
  blurLevel: 'none' | 'sm' | 'md' | 'lg';
  onChangeBlurLevel: (val: 'none' | 'sm' | 'md' | 'lg') => void;
  ambientMotion: boolean;
  onToggleAmbientMotion: (val: boolean) => void;
  onResetDefaults: () => void;
}

export const BackgroundCustomizer: React.FC<BackgroundCustomizerProps> = ({
  isOpen,
  onClose,
  selectedBgId,
  onSelectBg,
  overlayDarkness,
  onChangeOverlayDarkness,
  blurLevel,
  onChangeBlurLevel,
  ambientMotion,
  onToggleAmbientMotion,
  onResetDefaults,
}) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          {/* Backdrop with Motion */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm"
          />

          {/* Dialog Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 15 }}
            transition={{ type: 'spring', damping: 25, stiffness: 300 }}
            className="relative w-full max-w-3xl max-h-[90vh] bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden flex flex-col text-slate-100 z-10 backdrop-blur-xl"
          >
            {/* Header */}
            <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
                  <Palette className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                    <span>Tùy Chỉnh Phông Nền Giao Diện</span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 font-mono">
                      Real-time
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Thay đổi phong cách nền thư viện, bóng tối và hiệu ứng chuyển động trực quan
                  </p>
                </div>
              </div>

              <button
                onClick={onClose}
                className="w-8 h-8 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
                title="Đóng"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1">
              {/* Presets Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-semibold uppercase tracking-wider text-sky-400 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4" />
                    <span>Bộ Sưu Tập Phông Nền Đề Xuất</span>
                  </label>
                  <span className="text-xs text-slate-400">
                    {BACKGROUND_PRESETS.length} phong cách độc quyền
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {BACKGROUND_PRESETS.map((preset) => {
                    const isSelected = preset.id === selectedBgId;
                    return (
                      <motion.button
                        key={preset.id}
                        whileHover={{ y: -3, transition: { duration: 0.15 } }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => onSelectBg(preset.id)}
                        className={`group relative text-left rounded-xl overflow-hidden border p-3 transition-all flex flex-col justify-between h-36 ${
                          isSelected
                            ? 'border-sky-400 ring-2 ring-sky-400/40 bg-slate-800/90 shadow-lg shadow-sky-500/10'
                            : 'border-slate-700/80 bg-slate-800/50 hover:border-slate-600 hover:bg-slate-800/80'
                        }`}
                      >
                        {/* Background Thumbnail */}
                        {preset.imageSrc ? (
                          <div className="absolute inset-0 z-0">
                            <img
                              src={preset.imageSrc}
                              alt={preset.name}
                              referrerPolicy="no-referrer"
                              className="w-full h-full object-cover filter brightness-[0.35] group-hover:scale-105 transition-transform duration-500"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent" />
                          </div>
                        ) : (
                          <div
                            className={`absolute inset-0 bg-gradient-to-br ${preset.gradientClass} opacity-80`}
                          />
                        )}

                        {/* Top tag & Selected check */}
                        <div className="relative z-10 flex items-center justify-between w-full">
                          <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-900/80 text-sky-300 border border-slate-700/80 backdrop-blur-xs">
                            {preset.tag}
                          </span>
                          {isSelected && (
                            <span className="w-5 h-5 rounded-full bg-sky-500 text-white flex items-center justify-center shadow-md">
                              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                            </span>
                          )}
                        </div>

                        {/* Bottom Title & Description */}
                        <div className="relative z-10 mt-auto pt-2">
                          <div className="text-xs font-bold text-white group-hover:text-sky-300 transition-colors">
                            {preset.name}
                          </div>
                          <div className="text-[11px] text-slate-300 line-clamp-1 mt-0.5">
                            {preset.description}
                          </div>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* Adjustments Section */}
              <div className="pt-4 border-t border-slate-800/80 grid grid-cols-1 sm:grid-cols-2 gap-5">
                {/* Darkness Slider */}
                <div className="p-4 bg-slate-950/50 border border-slate-800 rounded-xl space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-sky-400" />
                      <span>Độ Tối Lớp Phủ (Độ Tương Phản)</span>
                    </span>
                    <span className="text-xs font-mono font-bold text-sky-400">
                      {overlayDarkness}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="35"
                    max="92"
                    step="1"
                    value={overlayDarkness}
                    onChange={(e) => onChangeOverlayDarkness(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-sky-500"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>Sáng hơn (35%)</span>
                    <span>Chuẩn đọc (75%)</span>
                    <span>Tối sâu (92%)</span>
                  </div>
                </div>

                {/* Blur Level Selection */}
                <div className="p-4 bg-slate-950/50 border border-slate-800 rounded-xl space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                      <Eye className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Độ Mờ Hậu Cảnh (Blur)</span>
                    </span>
                    <span className="text-xs font-mono text-emerald-400 uppercase">
                      {blurLevel}
                    </span>
                  </div>
                  <div className="grid grid-cols-4 gap-1.5">
                    {(['none', 'sm', 'md', 'lg'] as const).map((level) => (
                      <button
                        key={level}
                        onClick={() => onChangeBlurLevel(level)}
                        className={`py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                          blurLevel === level
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {level === 'none'
                          ? 'Rõ nét'
                          : level === 'sm'
                          ? 'Nhẹ'
                          : level === 'md'
                          ? 'Trung bình'
                          : 'Sâu'}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Làm mờ hậu cảnh giúp chữ và sơ đồ kỹ thuật nổi bật, không gây rối mắt.
                  </p>
                </div>
              </div>

              {/* Ambient Motion Toggle */}
              <div className="p-4 bg-slate-950/50 border border-slate-800 rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white flex items-center gap-1.5">
                      <span>Hiệu Ứng Chuyển Động Ánh Sáng Môi Trường</span>
                      <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Tạo luồng ánh sáng quang phổ chuyển động êm dịu ở nền sau giao diện
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onToggleAmbientMotion(!ambientMotion)}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                    ambientMotion ? 'bg-sky-600' : 'bg-slate-700'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                      ambientMotion ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>

            {/* Footer */}
            <div className="p-4 sm:p-5 border-t border-slate-800 bg-slate-950/70 flex items-center justify-between">
              <button
                onClick={onResetDefaults}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white flex items-center gap-1.5 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Khôi phục mặc định</span>
              </button>

              <button
                onClick={onClose}
                className="px-5 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-md shadow-sky-600/30 flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                <span>Áp Dụng Phông Nền Này</span>
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
