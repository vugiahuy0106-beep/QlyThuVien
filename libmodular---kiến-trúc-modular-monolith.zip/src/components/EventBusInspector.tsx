import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DomainEvent } from '../types';
import { eventBus } from '../core/eventBus';
import {
  Zap,
  Clock,
  CheckCircle2,
  AlertTriangle,
  X,
  Trash2,
  Play,
  ArrowRight,
  Send,
  Radio,
} from 'lucide-react';

interface EventBusInspectorProps {
  isOpen: boolean;
  onClose: () => void;
  events: DomainEvent[];
  onClear: () => void;
}

export const EventBusInspector: React.FC<EventBusInspectorProps> = ({
  isOpen,
  onClose,
  events,
  onClear,
}) => {
  const [selectedEventId, setSelectedEventId] = useState<string | null>(events[0]?.id || null);

  const selectedEvent = events.find((e) => e.id === selectedEventId) || events[0];

  const handleDispatchTestEvent = () => {
    eventBus.publish('TestDiagnosticPingEvent', 'Circulation', {
      timestamp: Date.now(),
      message: 'Kiểm tra thông tuyến In-Process Event Bus',
      pingOrigin: 'Simulator Inspector',
    });
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop with Motion */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
          />

          {/* Drawer Container with Motion */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="relative z-10 bg-slate-900/95 border-l border-slate-700/80 w-full max-w-2xl h-full shadow-2xl flex flex-col text-slate-100 backdrop-blur-xl"
          >
            {/* Drawer Header */}
            <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
                  <Zap className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    <span>In-Process Event Bus Inspector</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Quan sát sự kiện miền (Domain Events) truyền tải bất đồng bộ trong bộ nhớ RAM
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={onClear}
                  className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-lg transition-colors"
                  title="Xóa nhật ký sự kiện"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
                <button
                  onClick={onClose}
                  className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
                  title="Đóng"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Test Event Dispatcher Bar */}
            <div className="p-3 bg-slate-950/50 border-b border-slate-800/80 flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span>Trạng thái Bus: <strong className="text-emerald-400 font-mono">ONLINE (&lt;1ms latency)</strong></span>
              </div>
              <button
                onClick={handleDispatchTestEvent}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Bắn Sự Kiện Test</span>
              </button>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12">
              {/* Event Stream List */}
              <div className="md:col-span-5 border-r border-slate-800 overflow-y-auto p-3 space-y-2">
                <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider px-1">
                  Dòng Sự Kiện ({events.length})
                </div>

                {events.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-500">
                    Chưa có sự kiện nào được phát sinh. Hãy thử mượn/trả sách hoặc nhấn "Bắn Sự Kiện Test".
                  </div>
                ) : (
                  events.map((evt) => {
                    const isSelected = evt.id === (selectedEvent?.id || selectedEventId);
                    return (
                      <button
                        key={evt.id}
                        onClick={() => setSelectedEventId(evt.id)}
                        className={`w-full text-left p-3 rounded-xl border transition-all ${
                          isSelected
                            ? 'bg-sky-950/80 border-sky-400 text-white shadow-md'
                            : 'bg-slate-800/40 border-slate-800/80 hover:bg-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 mb-1">
                          <span className="text-sky-400 font-semibold">{evt.sourceModule}</span>
                          <span>{new Date(evt.occurredAt).toLocaleTimeString()}</span>
                        </div>
                        <div className="text-xs font-bold truncate leading-snug">{evt.eventName}</div>
                      </button>
                    );
                  })
                )}
              </div>

              {/* Event Detail View */}
              <div className="md:col-span-7 overflow-y-auto p-4 space-y-4">
                {selectedEvent ? (
                  <>
                    <div className="space-y-1">
                      <div className="text-[11px] font-mono text-slate-400">ID: {selectedEvent.id}</div>
                      <h4 className="text-base font-bold text-white leading-snug">{selectedEvent.eventName}</h4>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
                        <div className="text-slate-400 text-[11px]">Phân hệ phát ra (Source)</div>
                        <div className="font-bold text-sky-400 mt-0.5">{selectedEvent.sourceModule} Module</div>
                      </div>
                      <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl">
                        <div className="text-slate-400 text-[11px]">Độ trễ xử lý (In-Memory)</div>
                        <div className="font-bold text-emerald-400 mt-0.5">
                          {selectedEvent.latencyMs ? `${selectedEvent.latencyMs}ms` : '< 1ms'}
                        </div>
                      </div>
                    </div>

                    {selectedEvent.targetSubscribers && selectedEvent.targetSubscribers.length > 0 && (
                      <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl text-xs space-y-1">
                        <div className="text-slate-400 text-[11px]">Các phân hệ lắng nghe (Subscribers):</div>
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {selectedEvent.targetSubscribers.map((sub, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 rounded-full bg-slate-800 text-sky-300 text-[11px] border border-slate-700 font-mono"
                            >
                              {sub}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    <div>
                      <div className="text-xs font-semibold text-slate-300 mb-1.5">
                        Dữ liệu Payload Sự Kiện (JSON):
                      </div>
                      <pre className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl text-xs font-mono text-sky-300 overflow-x-auto leading-relaxed">
                        {JSON.stringify(selectedEvent.payload, null, 2)}
                      </pre>
                    </div>

                    <div className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl space-y-1.5 text-xs">
                      <div className="font-semibold text-slate-200">Đặc tính kỹ thuật của Domain Event:</div>
                      <ul className="text-slate-400 space-y-1 text-[11px] list-disc list-inside leading-relaxed">
                        <li>Dữ liệu mang tính chất bất biến (Immutable Value Object).</li>
                        <li>Được phát sau khi giao dịch cục bộ trong Bounded Context đã commit thành công.</li>
                        <li>Các subscriber xử lý độc lập, lỗi ở subscriber không làm ảnh hưởng emitter.</li>
                      </ul>
                    </div>
                  </>
                ) : (
                  <div className="p-6 text-center text-xs text-slate-500">
                    Chọn một sự kiện từ danh sách bên trái để kiểm tra chi tiết.
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
