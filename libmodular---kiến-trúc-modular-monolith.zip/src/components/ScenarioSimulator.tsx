import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ARCHITECTURE_SCENARIOS } from '../data/scenarios';
import { ScenarioDefinition, TraceStep } from '../types';
import {
  Play,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  AlertCircle,
  CheckCircle2,
  XCircle,
  Clock,
  Layers,
  Zap,
  Activity,
  ShieldCheck,
  Flame,
} from 'lucide-react';

export const ScenarioSimulator: React.FC = () => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(ARCHITECTURE_SCENARIOS[0].id);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [simulateFailure, setSimulateFailure] = useState<boolean>(false);

  const scenario = ARCHITECTURE_SCENARIOS.find((s) => s.id === selectedScenarioId) || ARCHITECTURE_SCENARIOS[0];

  const maxSteps = Math.max(scenario.traditionalSteps.length, scenario.modularSteps.length);

  // Auto-play timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isPlaying && currentStepIndex < maxSteps) {
      timer = setTimeout(() => {
        setCurrentStepIndex((prev) => prev + 1);
      }, 1600);
    } else if (currentStepIndex >= maxSteps) {
      setIsPlaying(false);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex, maxSteps]);

  const handleSelectScenario = (id: string) => {
    setSelectedScenarioId(id);
    setCurrentStepIndex(0);
    setIsPlaying(false);
  };

  const handleReset = () => {
    setCurrentStepIndex(0);
    setIsPlaying(false);
  };

  const handleNext = () => {
    if (currentStepIndex < maxSteps) {
      setCurrentStepIndex((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex((prev) => prev - 1);
    }
  };

  // Calculate cumulative durations
  const tradStepCurrent = scenario.traditionalSteps.slice(0, currentStepIndex);
  const modStepCurrent = scenario.modularSteps.slice(0, currentStepIndex);

  const tradDuration = tradStepCurrent.reduce((acc, s) => acc + s.durationMs, 0);
  const modDuration = modStepCurrent.reduce((acc, s) => acc + s.durationMs, 0);

  const isCompleted = currentStepIndex >= maxSteps;

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div>
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-sky-400 mb-1.5">
          <span className="px-2 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300">
            Phòng Thí Nghiệm Đồ Án
          </span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-slate-300">Mô phỏng Luồng Xử lý Động (Dynamic Trace Simulation)</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-slate-300">Thời gian thực</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-snug">
          Mô Phỏng & So Sánh Luồng Thực Thi Giữa Hai Kiến Trúc
        </h2>
        <p className="text-sm text-slate-300 mt-1.5 max-w-3xl leading-relaxed">
          Chọn kịch bản thực tế để theo dõi từng bước đi của dữ liệu, thời gian giữ khóa CSDL và mức độ ảnh hưởng khi xảy ra sự cố.
        </p>
      </div>

      {/* Scenario Selector Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {ARCHITECTURE_SCENARIOS.map((sc, idx) => {
          const isSelected = sc.id === selectedScenarioId;
          return (
            <motion.button
              key={sc.id}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => handleSelectScenario(sc.id)}
              className={`text-left p-3.5 rounded-xl border transition-all ${
                isSelected
                  ? 'bg-sky-950/80 border-sky-400 text-white shadow-lg shadow-sky-500/15 ring-1 ring-sky-400/50'
                  : 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-slate-600 hover:bg-slate-800/80'
              }`}
            >
              <div className="text-[11px] font-mono text-sky-400 font-semibold mb-1">
                KỊCH BẢN {idx + 1}
              </div>
              <div className="text-xs sm:text-sm font-bold leading-snug line-clamp-2">
                {sc.title.split(':')[1]?.trim() || sc.title}
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Scenario Overview Box */}
      <div className="p-4 sm:p-5 bg-slate-900/85 backdrop-blur-md border border-slate-700/80 rounded-2xl text-xs sm:text-sm space-y-2 text-slate-200 shadow-lg">
        <div className="font-bold text-white text-sm sm:text-base leading-snug flex items-center gap-2">
          <Activity className="w-4 h-4 text-sky-400 shrink-0" />
          <span>{scenario.title}</span>
        </div>
        <p className="text-slate-300 leading-relaxed font-normal">{scenario.description}</p>
      </div>

      {/* Playback Controls & Simulation Toggles */}
      <div className="flex flex-wrap items-center justify-between gap-4 p-4 sm:p-5 bg-slate-900/85 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-xl">
        <div className="flex flex-wrap items-center gap-2.5">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsPlaying(!isPlaying)}
            disabled={isCompleted && !isPlaying}
            className={`px-4 py-2.5 text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 ${
              isPlaying
                ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-amber-500/20'
                : 'bg-sky-600 hover:bg-sky-500 text-white shadow-sky-600/30 disabled:bg-slate-800 disabled:text-slate-500 disabled:cursor-not-allowed'
            }`}
          >
            {isPlaying ? (
              <span>Tạm dừng</span>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{currentStepIndex === 0 ? 'Bắt đầu mô phỏng' : 'Tiếp tục chạy'}</span>
              </>
            )}
          </motion.button>

          <button
            onClick={handlePrev}
            disabled={currentStepIndex === 0}
            className="p-2.5 border border-slate-700 rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Bước trước"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={handleNext}
            disabled={isCompleted}
            className="p-2.5 border border-slate-700 rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            title="Bước tiếp theo"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <button
            onClick={handleReset}
            className="p-2.5 border border-slate-700 rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white transition-colors"
            title="Đặt lại từ đầu"
          >
            <RotateCcw className="w-4 h-4" />
          </button>

          <span className="text-xs font-mono text-slate-400 px-2 py-1 bg-slate-950/60 rounded-lg border border-slate-800">
            Bước {Math.min(currentStepIndex, maxSteps)} / {maxSteps}
          </span>
        </div>

        {/* Failure Simulation Toggle */}
        <label className="flex items-center gap-2.5 cursor-pointer text-xs font-medium text-slate-200 bg-slate-950/60 px-3.5 py-2 rounded-xl border border-slate-700/80 hover:border-slate-600 transition-colors">
          <input
            type="checkbox"
            checked={simulateFailure}
            onChange={(e) => setSimulateFailure(e.target.checked)}
            className="rounded border-slate-600 text-rose-500 focus:ring-rose-500 bg-slate-800 w-4 h-4"
          />
          <Flame className="w-4 h-4 text-rose-400" />
          <span>Kích hoạt sự cố bên thứ ba (SMTP timeout / Network crash)</span>
        </label>
      </div>

      {/* Synchronized Side-by-Side Execution Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Column Left: Traditional Monolith Trace */}
        <div className="bg-slate-900/85 backdrop-blur-md border border-rose-500/40 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-rose-500/20">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-rose-400">
                Monolith Truyền Thống
              </div>
              <div className="text-sm font-bold text-white mt-0.5 leading-snug">
                Luồng Xử Lý Đồng Bộ & Gắn Kết Chặt
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Thời gian tích lũy</div>
              <div className="text-sm font-mono font-bold text-rose-400 tabular-nums">
                {tradDuration} ms
              </div>
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-3">
            {scenario.traditionalSteps.map((step, idx) => {
              const isPast = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex - 1;
              const isPending = idx >= currentStepIndex;

              return (
                <div
                  key={idx}
                  className={`p-3.5 rounded-xl border text-xs transition-all ${
                    isCurrent
                      ? 'bg-rose-950/70 border-rose-400 ring-2 ring-rose-500/40 shadow-lg text-white'
                      : isPast
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300 opacity-90'
                      : 'bg-slate-950/30 border-dashed border-slate-800 text-slate-500 opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold mb-1.5">
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-rose-900/80 text-rose-300 border border-rose-500/40 flex items-center justify-center text-[10px] font-mono font-bold">
                        {step.stepNumber}
                      </span>
                      <span className="text-white font-bold">{step.component}</span>
                    </span>
                    <span className="font-mono text-[11px] text-rose-300 tabular-nums">
                      +{step.durationMs}ms
                    </span>
                  </div>

                  <div className="text-slate-200 font-medium leading-relaxed">{step.action}</div>
                  <div className="text-slate-400 mt-1 leading-relaxed text-[11px]">{step.detail}</div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">{step.layerOrModule}</span>
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded-full border ${
                        step.couplingType === 'DirectDbJoin'
                          ? 'bg-rose-950/80 border-rose-500/40 text-rose-300'
                          : 'bg-slate-800 border-slate-700 text-slate-300'
                      }`}
                    >
                      {step.couplingType}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Outcome Status Card on Completion */}
          {isCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`p-4 rounded-xl border text-xs space-y-2.5 ${
                simulateFailure
                  ? 'bg-rose-950/80 border-rose-500/60 text-rose-100 shadow-lg'
                  : 'bg-amber-950/60 border-amber-500/40 text-amber-100'
              }`}
            >
              <div className="flex items-center gap-2 font-bold text-sm">
                {simulateFailure ? (
                  <>
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    <span>HỆ THỐNG ĐỔ VỠ: GIAO DỊCH BỊ ROLLBACK HỦY BỎ!</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
                    <span>KẾT QUẢ: {scenario.traditionalOutcome.status}</span>
                  </>
                )}
              </div>
              <p className="leading-relaxed text-slate-200">
                {simulateFailure
                  ? 'Do lỗi mạng khi gọi SMTP đồng bộ bên trong Transaction, toàn bộ thao tác bị hủy. Độc giả không thể hoàn thành việc mượn sách. Database bị giữ lock 5000ms!'
                  : scenario.traditionalOutcome.explanation}
              </p>
              <div className="pt-2 border-t border-slate-700/60 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="font-semibold text-slate-400">Vùng ảnh hưởng (Blast): </span>
                  <span className="text-white font-medium">{scenario.traditionalOutcome.blastRadius}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-400">Khóa dữ liệu: </span>
                  <span className="text-white font-medium">{scenario.traditionalOutcome.lockContention}</span>
                </div>
              </div>
            </motion.div>
          )}
        </div>

        {/* Column Right: Modular Monolith Trace */}
        <div className="bg-slate-900/85 backdrop-blur-md border border-sky-500/40 rounded-2xl p-5 sm:p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-sky-500/20">
            <div>
              <div className="text-xs font-bold uppercase tracking-wider text-sky-400">
                Modular Monolith
              </div>
              <div className="text-sm font-bold text-white mt-0.5 leading-snug">
                Ranh Giới Bounded Context & In-Process Event Bus
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-slate-400">Thời gian tích lũy</div>
              <div className="text-sm font-mono font-bold text-emerald-400 tabular-nums">
                {modDuration} ms
              </div>
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-3">
            {scenario.modularSteps.map((step, idx) => {
              const isPast = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex - 1;
              const isPending = idx >= currentStepIndex;

              return (
                <div
                  key={idx}
                  className={`p-3.5 rounded-xl border text-xs transition-all ${
                    isCurrent
                      ? 'bg-sky-950/70 border-sky-400 ring-2 ring-sky-500/40 shadow-lg text-white'
                      : isPast
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300 opacity-90'
                      : 'bg-slate-950/30 border-dashed border-slate-800 text-slate-500 opacity-50'
                  }`}
                >
                  <div className="flex items-center justify-between font-semibold mb-1.5">
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-sky-900/80 text-sky-300 border border-sky-500/40 flex items-center justify-center text-[10px] font-mono font-bold">
                        {step.stepNumber}
                      </span>
                      <span className="text-white font-bold">{step.component}</span>
                    </span>
                    <span className="font-mono text-[11px] text-emerald-400 tabular-nums">
                      +{step.durationMs}ms
                    </span>
                  </div>

                  <div className="text-slate-200 font-medium leading-relaxed">{step.action}</div>
                  <div className="text-slate-400 mt-1 leading-relaxed text-[11px]">{step.detail}</div>

                  <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400">{step.layerOrModule}</span>
                    <span
                      className={`font-mono text-[10px] px-2 py-0.5 rounded-full border ${
                        step.couplingType === 'LooseEvent'
                          ? 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300'
                          : 'bg-sky-950/80 border-sky-500/40 text-sky-300'
                      }`}
                    >
                      {step.couplingType}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Outcome Status Card on Completion */}
          {isCompleted && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-4 bg-emerald-950/70 border border-emerald-500/50 rounded-xl text-xs space-y-2.5 text-emerald-100 shadow-lg"
            >
              <div className="flex items-center gap-2 font-bold text-sm text-emerald-300">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>KẾT QUẢ: THÀNH CÔNG AN TOÀN (RESILIENT SUCCESS)</span>
              </div>
              <p className="leading-relaxed text-slate-200">
                {simulateFailure
                  ? 'Kể cả khi NotificationModule gặp lỗi mạng bên ngoài, nghiệp vụ mượn sách vẫn HOÀN TẤT THÀNH CÔNG trong CirculationModule. Sự kiện được đưa vào Retry Queue để gửi lại sau. Trải nghiệm người dùng không hề bị gián đoạn!'
                  : scenario.modularOutcome.explanation}
              </p>
              <div className="pt-2 border-t border-emerald-500/30 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="font-semibold text-slate-400">Vùng ảnh hưởng (Blast): </span>
                  <span className="text-white font-medium">{scenario.modularOutcome.blastRadius}</span>
                </div>
                <div>
                  <span className="font-semibold text-slate-400">Khóa dữ liệu: </span>
                  <span className="text-white font-medium">{scenario.modularOutcome.lockContention}</span>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};
