import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Cpu, Sparkles, BookOpen } from 'lucide-react';

interface ArchitectureHeroProps {
  onExploreSimulator: () => void;
  onExploreApp: () => void;
}

export const ArchitectureHero: React.FC<ArchitectureHeroProps> = ({
  onExploreSimulator,
  onExploreApp,
}) => {
  return (
    <section className="relative overflow-hidden border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Academic Brief & Value Proposition */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4 }}
            className="lg:col-span-7 space-y-6"
          >
            {/* Unboxed Metadata Header with adequate vertical padding */}
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-sky-400 py-1">
              <span className="px-2.5 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300">
                Đề tài Nghiên cứu Khoa học
              </span>
              <span aria-hidden="true" className="text-slate-500">·</span>
              <span className="text-slate-300">Môn: Các vấn đề hiện đại của CNTT</span>
              <span aria-hidden="true" className="text-slate-500">·</span>
              <span className="text-slate-300">Khóa Luận / Đồ Án Chuyên Đề</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-snug sm:leading-snug lg:leading-[1.25] pt-1">
              Hệ Thống Quản Lý Thư Viện Kiến Trúc{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 via-teal-300 to-indigo-400">
                Modular Monolith
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed font-normal">
              Giải pháp kiến trúc phần mềm dung hòa hoàn hảo: Giữ trọn tính bao đóng và ranh giới nghiệp vụ sạch của{' '}
              <strong className="text-white font-semibold">Microservices</strong>, đồng thời loại bỏ 100% sự phức tạp phân tán, độ trễ mạng và chi phí vận hành đắt đỏ thông qua mô hình{' '}
              <strong className="text-white font-semibold">In-Process Event Bus & Bounded Contexts</strong>.
            </p>

            {/* Micro-metrics with clean unboxed text and dividers */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-slate-800/80">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-xs">
                <div className="text-2xl font-bold font-mono tabular-nums text-white leading-normal">
                  5 Bounded
                </div>
                <div className="text-xs text-slate-400 mt-0.5 leading-normal">Contexts độc lập</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-xs">
                <div className="text-2xl font-bold font-mono tabular-nums text-emerald-400 leading-normal">
                  &lt; 5ms
                </div>
                <div className="text-xs text-slate-400 mt-0.5 leading-normal">Độ trễ In-Process Event</div>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-xs">
                <div className="text-2xl font-bold font-mono tabular-nums text-sky-400 leading-normal">
                  1 Artifact
                </div>
                <div className="text-xs text-slate-400 mt-0.5 leading-normal">Triển khai tối giản</div>
              </div>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onExploreSimulator}
                className="px-5 py-3 text-sm font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-lg shadow-sky-600/25 flex items-center gap-2"
              >
                <span>Xem Mô phỏng So sánh</span>
                <ArrowRight className="w-4 h-4" />
              </motion.button>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={onExploreApp}
                className="px-5 py-3 text-sm font-medium text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl transition-all flex items-center gap-2 backdrop-blur-xs"
              >
                <BookOpen className="w-4 h-4 text-sky-400" />
                <span>Trải nghiệm Phần mềm Thư viện</span>
              </motion.button>
            </div>
          </motion.div>

          {/* Right Column: High-Fidelity Architecture Visual Asset */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
            className="lg:col-span-5 relative"
          >
            <div className="relative rounded-2xl overflow-hidden border border-slate-700/80 shadow-2xl bg-slate-900/80 backdrop-blur-md group">
              <img
                src="/src/assets/images/hero_modular_monolith_1790582976381.jpg"
                alt="Sơ đồ kiến trúc Modular Monolith"
                referrerPolicy="no-referrer"
                className="w-full h-auto object-cover transform group-hover:scale-105 transition-transform duration-500 filter brightness-95"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/95 via-slate-950/40 to-transparent pointer-events-none" />

              {/* Architectural Highlights Overlay with generous text padding */}
              <div className="absolute bottom-4 left-4 right-4 text-xs space-y-1.5 pointer-events-none">
                <div className="flex items-center justify-between text-slate-300">
                  <span className="font-bold text-white text-sm leading-normal">
                    Kiến trúc Thư viện: 5 Phân hệ lõi
                  </span>
                  <span className="font-mono text-emerald-400 flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Ranh giới cô lập
                  </span>
                </div>
                <div className="text-slate-300 text-xs leading-normal">
                  Catalog · Patron/Độc giả · Circulation/Mượn trả · Fine/Phạt · Notification
                </div>
              </div>
            </div>

            {/* Quick Note Badges */}
            <div className="mt-3 flex items-center justify-between text-xs text-slate-300 px-1">
              <span className="flex items-center gap-1.5 font-medium">
                <Cpu className="w-3.5 h-3.5 text-sky-400" />
                <span>Single Process Deployment</span>
              </span>
              <span className="flex items-center gap-1.5 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Zero Microservice Tax</span>
              </span>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
