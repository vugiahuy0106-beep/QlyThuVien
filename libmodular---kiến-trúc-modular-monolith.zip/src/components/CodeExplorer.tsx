import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CODE_SAMPLES, CodeSnippetItem } from '../data/codebaseSamples';
import {
  Code2,
  FileCode,
  ShieldCheck,
  AlertTriangle,
  FolderTree,
  Terminal,
  CheckCircle,
  XCircle,
  Copy,
  Check,
} from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [selectedSnippetId, setSelectedSnippetId] = useState<string>(CODE_SAMPLES[0].id);
  const [activeCodeTab, setActiveCodeTab] = useState<'modular' | 'traditional'>('modular');
  const [copied, setCopied] = useState(false);
  const [simulatedViolation, setSimulatedViolation] = useState<'idle' | 'testing' | 'failed'>('idle');

  const snippet = CODE_SAMPLES.find((s) => s.id === selectedSnippetId) || CODE_SAMPLES[0];

  const handleCopy = () => {
    const code = activeCodeTab === 'modular' ? snippet.modularCode : snippet.traditionalCode;
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunArchUnitTest = () => {
    setSimulatedViolation('testing');
    setTimeout(() => {
      setSimulatedViolation('failed');
    }, 700);
  };

  const handleResetArchUnitTest = () => {
    setSimulatedViolation('idle');
  };

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div>
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-sky-400 mb-1.5">
          <span className="px-2 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300">
            Khảo Sát Mã Nguồn & Ranh Giới
          </span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-slate-300">Architectural Fitness Functions</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-slate-300">Clean Architecture</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-snug">
          So Sánh Tổ Chức Mã Nguồn & Cơ Chế Kiểm Soát Ranh Giới
        </h2>
        <p className="text-sm text-slate-300 mt-1.5 max-w-3xl leading-relaxed">
          So sánh sự khác biệt trong mã nguồn thực tế: từ cấu trúc cây thư mục, thiết kế Interface Contract đến công cụ tự động hóa kiểm tra ranh giới (ArchUnit / ESLint).
        </p>
      </div>

      {/* Snippet Selection Tabs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {CODE_SAMPLES.map((item) => {
          const isSelected = item.id === selectedSnippetId;
          return (
            <motion.button
              key={item.id}
              whileHover={{ y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setSelectedSnippetId(item.id);
                setSimulatedViolation('idle');
              }}
              className={`text-left p-3.5 rounded-xl border transition-all ${
                isSelected
                  ? 'bg-sky-950/80 border-sky-400 text-white shadow-lg shadow-sky-500/15 ring-1 ring-sky-400/50'
                  : 'bg-slate-900/80 border-slate-700/80 text-slate-300 hover:border-slate-600 hover:bg-slate-800/80'
              }`}
            >
              <div className="text-[10px] font-mono text-sky-400 font-semibold mb-1 uppercase">
                {item.category}
              </div>
              <div className="text-xs sm:text-sm font-bold truncate leading-snug">{item.title.split(':')[0]}</div>
            </motion.button>
          );
        })}
      </div>

      {/* Main Code Comparison Box */}
      <div className="bg-slate-950/90 text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl overflow-hidden backdrop-blur-md">
        {/* Code Header Bar */}
        <div className="p-3.5 bg-slate-900/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setActiveCodeTab('modular')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeCodeTab === 'modular'
                  ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-sky-300" />
              <span>Modular Monolith (Chuẩn Khuyến Nghị)</span>
            </button>

            <button
              onClick={() => setActiveCodeTab('traditional')}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeCodeTab === 'traditional'
                  ? 'bg-rose-700 text-white shadow-md shadow-rose-700/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-300" />
              <span>Monolith Truyền Thống (Dễ Suy Thoái)</span>
            </button>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-xs font-mono text-slate-400 hidden sm:inline">
              {snippet.fileName}
            </span>
            <button
              onClick={handleCopy}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title="Sao chép mã nguồn"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="p-4 sm:p-6 overflow-x-auto font-mono text-xs sm:text-[13px] leading-relaxed">
          <pre
            className={`${
              activeCodeTab === 'modular' ? 'text-emerald-300' : 'text-rose-200'
            }`}
          >
            {activeCodeTab === 'modular' ? snippet.modularCode : snippet.traditionalCode}
          </pre>
        </div>

        {/* Architectural Insight Footer */}
        <div className="p-4 sm:p-5 bg-slate-900/90 border-t border-slate-800 text-xs sm:text-sm text-slate-300 space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">Nguyên lý cốt lõi:</span>
            <span className="text-sky-400 font-mono">{snippet.keyPrinciple}</span>
          </div>
          <p className="text-slate-400 leading-relaxed font-normal">{snippet.explanation}</p>
        </div>
      </div>

      {/* Interactive Boundary Test Sandbox */}
      <div className="p-5 sm:p-6 bg-slate-900/85 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-sky-400" />
              <span>Công Cụ Thử Nghiệm Kiểm Tra Ranh Giới (ArchUnit Sandbox)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">
              Giả lập tình huống khi lập trình viên cố tình import thư mục <code className="text-rose-400 bg-slate-950 px-1 py-0.5 rounded">modules/catalog/internal/</code> vào <code className="text-sky-400 bg-slate-950 px-1 py-0.5 rounded">modules/circulation/</code>.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {simulatedViolation === 'idle' ? (
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleRunArchUnitTest}
                className="px-4 py-2 text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-md shadow-sky-600/25"
              >
                Chạy kiểm tra CI/CD (npm run test:arch)
              </motion.button>
            ) : (
              <button
                onClick={handleResetArchUnitTest}
                className="px-4 py-2 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white rounded-xl transition-colors border border-slate-700"
              >
                Đặt lại
              </button>
            )}
          </div>
        </div>

        {/* Terminal Output */}
        <div className="p-4 sm:p-5 bg-slate-950 border border-slate-800 rounded-xl font-mono text-xs space-y-1.5 leading-relaxed">
          <div className="text-slate-500">$ npx archunit-ts --project ./src</div>

          {simulatedViolation === 'idle' && (
            <div className="text-emerald-400 pt-1">
              ✓ All 5 modules adhere to bounded context isolation rules. (0 boundary violations)
            </div>
          )}

          {simulatedViolation === 'testing' && (
            <div className="text-sky-400 pt-1 animate-pulse">
              Running Architectural Fitness Functions scanning 142 source files...
            </div>
          )}

          {simulatedViolation === 'failed' && (
            <div className="pt-2 space-y-2 text-rose-400">
              <div className="font-bold flex items-center gap-2">
                <XCircle className="w-4 h-4 text-rose-500 shrink-0" />
                <span>BUILD FAILED: Architectural Rule Violation Detected!</span>
              </div>
              <div className="text-slate-400 pl-6 text-[11px] sm:text-xs space-y-1">
                <div className="text-amber-400">[Rule: no-cross-module-internal-imports]</div>
                <div className="text-rose-300">
                  File: /src/modules/circulation/BorrowBookUseCase.ts:4:1
                </div>
                <div>
                  Error: Module 'circulation' must NOT import internal package 'catalog/internal/BookEntity'.
                </div>
                <div className="text-emerald-400">
                  Fix: Use the public contract 'ICatalogModule' in 'modules/catalog/public/ICatalogModule.ts' instead.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
