import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Layers,
  BookOpen,
  GitCompare,
  Code2,
  Award,
  Zap,
  Palette,
  Menu,
  X,
  Search,
  Activity,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { soundFX } from '../core/soundEffects';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  eventCount: number;
  onOpenEventBus: () => void;
  onOpenBgCustomizer: () => void;
  onOpenCommandPalette: () => void;
  currentBgName?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  eventCount,
  onOpenEventBus,
  onOpenBgCustomizer,
  onOpenCommandPalette,
  currentBgName = 'Thư Viện Số',
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(soundFX.enabled);

  const navItems = [
    { id: 'comparison', label: 'So sánh Kiến trúc', icon: GitCompare },
    { id: 'simulator', label: 'Mô phỏng Kịch bản', icon: Zap },
    { id: 'demo', label: 'Phần mềm Thư viện', icon: BookOpen },
    { id: 'benchmark', label: 'Đo Tải & Hiệu Năng', icon: Activity },
    { id: 'code', label: 'Mã nguồn & Ranh giới', icon: Code2 },
    { id: 'defense', label: 'Báo cáo & Bảo vệ', icon: Award },
  ];

  const handleTabClick = (tabId: string) => {
    soundFX.playSwitch();
    setActiveTab(tabId);
  };

  const handleToggleSound = () => {
    const newState = soundFX.toggle();
    setSoundEnabled(newState);
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 text-slate-100 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Zone 1: Wordmark & Architecture Subtitle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => handleTabClick('comparison')}
            className="text-base sm:text-lg font-bold tracking-tight text-white flex items-center gap-2.5 hover:text-sky-300 transition-colors text-left"
          >
            <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Layers className="w-4 h-4" />
            </div>
            <div>
              <span className="font-extrabold block text-white text-base leading-tight">LibModular</span>
              <span className="hidden sm:inline-block text-[11px] text-slate-400 font-normal leading-normal">
                Modular Monolith Architecture
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Navigation Links with Animated Active Indicator */}
        <nav className="hidden xl:flex items-center space-x-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`relative flex items-center gap-2 px-3 py-2 text-xs xl:text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
                  isActive
                    ? 'text-sky-400 font-semibold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-nav-pill"
                    className="absolute inset-0 bg-slate-800/90 border border-slate-700/80 rounded-lg shadow-inner -z-10"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                <span className="leading-normal">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Interactive Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Quick Command Palette Button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              soundFX.playClick();
              onOpenCommandPalette();
            }}
            className="px-2.5 py-1.5 text-xs text-slate-300 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-all flex items-center gap-1.5"
            title="Mở hộp tìm kiếm nhanh (Ctrl+K)"
          >
            <Search className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden md:inline text-[11px] font-mono text-slate-400">⌘K</span>
          </motion.button>

          {/* Sound Effect Toggle */}
          <button
            onClick={handleToggleSound}
            className="p-1.5 sm:p-2 text-slate-400 hover:text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-all"
            title={soundEnabled ? 'Tắt âm thanh tương tác' : 'Bật âm thanh tương tác'}
          >
            {soundEnabled ? (
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-slate-500" />
            )}
          </button>

          {/* Change Background Button */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              soundFX.playClick();
              onOpenBgCustomizer();
            }}
            className="px-2.5 sm:px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-sky-500/50 rounded-lg transition-all flex items-center gap-1.5 shadow-xs group"
            title="Tùy chỉnh ảnh nền và hiệu ứng"
          >
            <Palette className="w-3.5 h-3.5 text-sky-400 group-hover:rotate-12 transition-transform" />
            <span className="hidden sm:inline font-medium">Đổi Nền</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono hidden lg:inline max-w-[85px] truncate">
              {currentBgName}
            </span>
          </motion.button>

          {/* Event Bus Drawer Toggle */}
          <motion.button
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              soundFX.playClick();
              onOpenEventBus();
            }}
            className="relative px-2.5 sm:px-3 py-1.5 text-xs font-medium text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-lg transition-colors flex items-center gap-1.5"
            title="Mở nhật ký In-Process Event Bus"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="hidden sm:inline">Event Bus</span>
            <span className="text-[11px] font-mono tabular-nums text-emerald-400 font-semibold">
              ({eventCount})
            </span>
          </motion.button>

          {/* Mobile menu toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-white"
            title="Menu điều hướng"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="xl:hidden border-t border-slate-800 bg-slate-950/95 px-4 py-3 space-y-1.5 shadow-xl"
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  handleTabClick(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-lg transition-colors ${
                  isActive
                    ? 'bg-slate-800 text-sky-400 border border-slate-700'
                    : 'text-slate-300 hover:text-white hover:bg-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-sky-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </motion.div>
      )}
    </header>
  );
};
