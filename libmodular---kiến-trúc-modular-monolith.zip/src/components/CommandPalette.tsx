import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  BookOpen,
  Zap,
  GitCompare,
  Code2,
  Award,
  Layers,
  Palette,
  Activity,
  X,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import { soundFX } from '../core/soundEffects';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (tab: string) => void;
  onOpenEventBus: () => void;
  onOpenBgCustomizer: () => void;
}

interface CommandItem {
  id: string;
  title: string;
  category: 'Điều hướng' | 'Kho Sách' | 'Nghiên Cứu' | 'Hành Động';
  icon: typeof Search;
  action: () => void;
  shortcut?: string;
  description?: string;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenEventBus,
  onOpenBgCustomizer,
}) => {
  const [query, setQuery] = useState('');

  // Keyboard shortcut listener for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        soundFX.playClick();
        if (isOpen) {
          onClose();
        } else {
          // Open handled by parent or state
        }
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const COMMANDS: CommandItem[] = [
    {
      id: 'nav-benchmark',
      title: 'Phòng Thử Nghiệm Đo Tải & Hiệu Năng (Benchmark Lab)',
      category: 'Điều hướng',
      icon: Activity,
      action: () => {
        onNavigate('benchmark');
        onClose();
      },
      shortcut: 'Tab 6',
      description: 'Giả lập 5,000 requests đồng thời đo thông lượng & p95 latency',
    },
    {
      id: 'nav-comparison',
      title: 'So Sánh Đối Chiếu Kiến Trúc (Architectural Comparison)',
      category: 'Điều hướng',
      icon: GitCompare,
      action: () => {
        onNavigate('comparison');
        onClose();
      },
      shortcut: 'Tab 1',
      description: 'Monolith truyền thống vs. Modular Monolith vs. Microservices',
    },
    {
      id: 'nav-simulator',
      title: 'Mô Phỏng Kịch Bản Luồng Dữ Liệu (Scenario Simulator)',
      category: 'Điều hướng',
      icon: Zap,
      action: () => {
        onNavigate('simulator');
        onClose();
      },
      shortcut: 'Tab 2',
      description: 'Mô phỏng tranh chấp khóa CSDL và cô lập lỗi',
    },
    {
      id: 'nav-demo',
      title: 'Ứng Dụng Quản Lý Thư Viện Đại Học (Live Demo)',
      category: 'Điều hướng',
      icon: BookOpen,
      action: () => {
        onNavigate('demo');
        onClose();
      },
      shortcut: 'Tab 3',
      description: '5 phân hệ: Kho sách, Độc giả, Mượn trả, Tiền phạt, Thông báo',
    },
    {
      id: 'nav-code',
      title: 'Khảo Sát Mã Nguồn & Kiểm Soát Ranh Giới (ArchUnit Sandbox)',
      category: 'Điều hướng',
      icon: Code2,
      action: () => {
        onNavigate('code');
        onClose();
      },
      shortcut: 'Tab 4',
      description: 'Kiểm thử kiến trúc Architectural Fitness Functions',
    },
    {
      id: 'nav-defense',
      title: 'Hồ Sơ Bảo Vệ Đồ Án & 25 Câu Hỏi Phản Biện Hội Đồng',
      category: 'Điều hướng',
      icon: Award,
      action: () => {
        onNavigate('defense');
        onClose();
      },
      shortcut: 'Tab 5',
      description: 'Slide trình bày, ma trận đánh đổi và câu trả lời mẫu điểm 10',
    },
    {
      id: 'action-bg',
      title: 'Tùy Chỉnh Phông Nền Giao Diện & Ánh Sáng Môi Trường',
      category: 'Hành Động',
      icon: Palette,
      action: () => {
        onClose();
        onOpenBgCustomizer();
      },
      description: 'Chọn 6 ảnh nền thư viện cao cấp, chỉnh độ tối và mờ hậu cảnh',
    },
    {
      id: 'action-eventbus',
      title: 'Mở Ngăn Kéo In-Process Domain Event Bus Inspector',
      category: 'Hành Động',
      icon: Zap,
      action: () => {
        onClose();
        onOpenEventBus();
      },
      description: 'Xem nhật ký phát sinh sự kiện miền trực tiếp trong RAM',
    },
  ];

  const filtered = COMMANDS.filter((cmd) => {
    const q = query.toLowerCase().trim();
    if (!q) return true;
    return (
      cmd.title.toLowerCase().includes(q) ||
      cmd.description?.toLowerCase().includes(q) ||
      cmd.category.toLowerCase().includes(q)
    );
  });

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:pt-20">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-slate-950/75 backdrop-blur-md"
          />

          {/* Palette Dialog */}
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -10 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-2xl bg-slate-900/95 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden z-10 text-slate-100 backdrop-blur-xl flex flex-col max-h-[80vh]"
          >
            {/* Search Input Box */}
            <div className="p-4 border-b border-slate-800 flex items-center gap-3 bg-slate-950/60">
              <Search className="w-5 h-5 text-sky-400 shrink-0" />
              <input
                type="text"
                autoFocus
                placeholder="Tìm kiếm tính năng, tài liệu, kịch bản, câu hỏi phản biện... (Cmd+K)"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full bg-transparent border-0 text-white placeholder-slate-400 focus:outline-hidden text-sm sm:text-base leading-normal"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="p-1 rounded-md text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Commands List */}
            <div className="p-3 overflow-y-auto space-y-1 flex-1">
              {filtered.length === 0 ? (
                <div className="p-8 text-center text-sm text-slate-400">
                  Không tìm thấy mục nào khớp với "{query}". Thử tìm "Benchmark", "Mượn sách", hoặc "Slide".
                </div>
              ) : (
                filtered.map((item) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={item.id}
                      onClick={() => {
                        soundFX.playClick();
                        item.action();
                      }}
                      className="w-full p-3 rounded-xl hover:bg-slate-800/80 border border-transparent hover:border-slate-700/80 transition-all text-left flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-slate-800 group-hover:bg-sky-500/20 text-slate-300 group-hover:text-sky-400 flex items-center justify-center transition-colors">
                          <Icon className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="text-xs sm:text-sm font-bold text-white group-hover:text-sky-300 transition-colors leading-snug">
                            {item.title}
                          </div>
                          {item.description && (
                            <div className="text-[11px] text-slate-400 line-clamp-1 leading-normal">
                              {item.description}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {item.shortcut && (
                          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-950 text-slate-400 border border-slate-800">
                            {item.shortcut}
                          </span>
                        )}
                        <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-sky-400 group-hover:translate-x-0.5 transition-all" />
                      </div>
                    </button>
                  );
                })
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t border-slate-800/80 bg-slate-950/70 flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>Mẹo: Nhấn ESC để đóng</span>
              <span>LibModular Quick Search</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
