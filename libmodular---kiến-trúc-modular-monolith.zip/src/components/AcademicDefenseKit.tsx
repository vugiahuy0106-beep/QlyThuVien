import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DEFENSE_QUESTIONS, ARCHITECTURE_METRICS, DefenseQuestion } from '../data/defenseData';
import {
  Award,
  BookOpen,
  ChevronRight,
  ChevronLeft,
  Download,
  HelpCircle,
  CheckCircle2,
  Table,
  FileText,
  Star,
  Layers,
  ArrowRight,
  Maximize2,
  Minimize2,
  Clock,
  Play,
  Pause,
  X,
} from 'lucide-react';
import { soundFX } from '../core/soundEffects';

export const AcademicDefenseKit: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'slides' | 'qa' | 'matrix'>('slides');
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState<DefenseQuestion['category'] | 'All'>('All');
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(DEFENSE_QUESTIONS[0].id);

  // Fullscreen Presentation Mode State
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [presentationSeconds, setPresentationSeconds] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Defense Presentation Slides
  const SLIDES = [
    {
      title: '1. Đặt Vấn Đề: Khủng Hoảng Kiến Trúc & Cạm Bẫy Microservices Hype',
      subtitle: 'Tại sao Monolith truyền thống thoái hóa và Microservices lại quá phức tạp?',
      bullets: [
        'Monolith truyền thống tổ chức theo tầng ngang (Layered) thường biến thành "Big Ball of Mud" sau 1-2 năm phát triển do thiếu ranh giới bảo vệ.',
        'Tuy nhiên, phong trào "Microservices hóa" sớm đem lại thảm họa hạ tầng (Distributed Systems Tax): độ trễ mạng, distributed transactions (Saga), cụm Kubernetes đắt đỏ và phân rã thành "Distributed Monolith".',
        'Định luật Monolith First (Martin Fowler): Đừng bao giờ bắt đầu bằng vi dịch vụ nếu chưa làm chủ được một khối Monolith có cấu trúc sạch.',
        'Mục tiêu đồ án: Thiết kế hệ thống Thư viện Đại học theo kiến trúc Modular Monolith - dung hòa ưu điểm của cả hai thế giới.',
      ],
      keyTakeaway: 'Modular Monolith là kiến trúc mặc định lý tưởng nhất cho 95% dự án phần mềm doanh nghiệp vừa và lớn hiện nay.',
    },
    {
      title: '2. Bản Chất Của Modular Monolith & Thiết Kế Bounded Contexts',
      subtitle: 'Ranh giới Bounded Context độc lập bên trong cùng một thực thi tiến trình',
      bullets: [
        'Hệ thống thư viện được phân chia thành 5 Bounded Contexts theo Domain-Driven Design (DDD): Catalog, Patron, Circulation, Fine & Billing, Notification.',
        'Mỗi phân hệ tuân thủ quy tắc Che giấu thông tin (Information Hiding): Chỉ có thư mục public/ (chứa Interface & DTO) được công khai; thư mục internal/ (chứa Entity, DAO, logic nghiệp vụ) bị bao đóng hoàn toàn.',
        'Sử dụng các công cụ kiểm thử kiến trúc (Architectural Fitness Functions như ArchUnit / ESLint Boundaries) trong CI/CD để chặn đứng vi phạm ranh giới từ dòng lệnh build.',
        'Cơ sở dữ liệu được phân chia theo Logical Schemas riêng biệt, cấm hoàn toàn các câu lệnh SQL JOIN chéo giữa các phân hệ.',
      ],
      keyTakeaway: 'Ranh giới logic chặt chẽ tương đương Microservices, nhưng chạy trên cùng 1 tiến trình và 1 database connection pool.',
    },
    {
      title: '3. Cơ Chế Giao Tiếp: Public Contract & In-Process Domain Event Bus',
      subtitle: 'Kết hợp gọi hàm đồng bộ qua Interface và phát sự kiện bất đồng bộ trong bộ nhớ',
      bullets: [
        'Truy vấn đọc (Read Queries): Gọi trực tiếp qua Interface công khai (vd: IPatronModule.canBorrow), độ trễ dưới 1 microsecond trong bộ nhớ RAM.',
        'Thay đổi trạng thái (Commands): Giao dịch hoàn tất trong module chủ quản, sau đó phát Domain Event (vd: LoanCreatedDomainEvent, BookReturnedOverdueEvent).',
        'In-Process Event Bus vận hành theo mẫu Publish-Subscribe ngay trong RAM: Không cần Kafka hay RabbitMQ, không mất chi phí mạng, không có overhead tuần tự hóa dữ liệu.',
        'Cô lập lỗi (Fault Isolation): Lỗi gửi email ở Notification Module hoàn toàn không làm rollback giao dịch mượn sách cốt lõi của Circulation Module.',
      ],
      keyTakeaway: 'Event-Driven Architecture không nhất thiết phải dùng message broker phân tán; in-process event bus cho thông lượng hàng chục nghìn event/giây.',
    },
    {
      title: '4. Đánh Đổi Kiến Trúc & Chi Phí Thực Tế (Trade-off Analysis)',
      subtitle: 'So sánh định lượng giữa Monolith Truyền Thống, Modular Monolith và Microservices',
      bullets: [
        'Chi phí hạ tầng: Modular Monolith chỉ tốn ~20-50 USD/tháng (1 VPS/Cloud Run) so với 500-1500 USD/tháng cho cụm Kubernetes/Service Mesh của Microservices.',
        'Độ trễ (Latency): Gọi in-memory đạt < 0.1ms; Microservices tốn 15ms - 50ms cho các network hops và parse JSON qua lại.',
        'Quản lý giao dịch: Duy trì tính toàn vẹn ACID cục bộ, không phải đau đầu xử lý 2PC (Two-Phase Commit) hay Eventual Consistency phức tạp.',
        'Tốc độ phát triển: Lập trình viên khởi động toàn bộ hệ thống trên laptop trong 3 giây mà không cần dựng 10 container docker-compose.',
      ],
      keyTakeaway: 'Tối ưu hóa "Developer Experience" và "Total Cost of Ownership (TCO)" cho doanh nghiệp.',
    },
    {
      title: '5. Lộ Trình Tiến Hóa Sang Microservices (Evolutionary Architecture)',
      subtitle: 'Modular Monolith là bàn đạp hoàn hảo để trích xuất vi dịch vụ khi cần thiết',
      bullets: [
        'Khi thư viện đạt quy mô liên trường (vài trăm nghìn sinh viên) và phân hệ Tra cứu (Catalog Search) cần scale độc lập:',
        'Bước 1: Tách thư mục src/modules/catalog sang repository độc lập.',
        'Bước 2: Thay thế implementation nội bộ của ICatalogModule bằng gRPC hoặc HTTP Client Adapter (Strangler Fig Pattern). Các module còn lại không sửa 1 dòng code!',
        'Bước 3: Cắm Event Bus Adapter chuyển từ in-memory sang Apache Kafka / RabbitMQ.',
        'Thời gian chuyển đổi chỉ tính bằng ngày thay vì mất hàng năm tái cấu trúc monolith cũ.',
      ],
      keyTakeaway: 'Kiến trúc tiến hóa bền vững: Hãy bắt đầu với Modular Monolith, và chỉ tách Microservices khi dữ liệu và tải thực sự đòi hỏi!',
    },
  ];

  // Presentation timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPresentationOpen && isTimerRunning) {
      interval = setInterval(() => {
        setPresentationSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPresentationOpen, isTimerRunning]);

  // Keyboard navigation for presentation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isPresentationOpen) return;
      if (e.key === 'ArrowRight' || e.key === ' ') {
        handleNextSlide();
      } else if (e.key === 'ArrowLeft') {
        handlePrevSlide();
      } else if (e.key === 'Escape') {
        setIsPresentationOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPresentationOpen, currentSlideIndex]);

  const handleNextSlide = () => {
    soundFX.playClick();
    if (currentSlideIndex < SLIDES.length - 1) {
      setCurrentSlideIndex((prev) => prev + 1);
    }
  };

  const handlePrevSlide = () => {
    soundFX.playClick();
    if (currentSlideIndex > 0) {
      setCurrentSlideIndex((prev) => prev - 1);
    }
  };

  const formatTimer = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Export Academic Report as Markdown file
  const handleExportMarkdown = () => {
    soundFX.playSuccess();
    const reportContent = `# BÁO CÁO ĐỒ ÁN MÔN HỌC: CÁC VẤN ĐỀ HIỆN ĐẠI CỦA CÔNG NGHỆ THÔNG TIN
## Đề tài: Nghiên Cứu và Ứng Dụng Kiến Trúc Modular Monolith Trong Hệ Thống Quản Lý Thư Viện Đại Học
**Sinh viên thực hiện:** Nhóm nghiên cứu kiến trúc phần mềm
**Ngày lập báo cáo:** ${new Date().toLocaleDateString('vi-VN')}

---

### 1. TÓM TẮT ĐỀ TÀI (ABSTRACT)
Trong bối cảnh các hệ thống thông tin doanh nghiệp đang đối mặt với sự đánh đổi khốc liệt giữa tính phức tạp phân tán của Microservices và sự thoái hóa thành "Big Ball of Mud" của Monolith truyền thống, kiến trúc **Modular Monolith** nổi lên như một giải pháp chuẩn mực. Đồ án xây dựng một hệ thống Quản lý Thư viện Đại học hoàn chỉnh áp dụng các nguyên lý Domain-Driven Design (DDD), phân chia 5 Bounded Contexts độc lập (Catalog, Patron, Circulation, Fine, Notification), giao tiếp qua Public Contract và In-Process Domain Event Bus.

### 2. CÁC NGUYÊN LÝ THIẾT KẾ CỐT LÕI
1. **Bounded Context & High Cohesion:** Mỗi module tự đóng gói trọn vẹn nghiệp vụ, cơ sở dữ liệu logic và logic miền.
2. **Information Hiding (David Parnas):** Tuyệt đối che giấu tầng DAO và Entity nội bộ sau thư mục \`internal/\`.
3. **In-Process Event Bus:** Phân tách luồng xử lý bất đồng bộ trong bộ nhớ RAM, loại bỏ hiệu ứng lỗi dây chuyền (Cascading Failure).
4. **Architectural Fitness Functions:** Kiểm soát ranh giới tự động bằng ArchUnit / ESLint trong CI/CD.

### 3. MA TRẬN SO SÁNH ĐÁNH ĐỔI
| Tiêu chí | Monolith Truyền Thống | Modular Monolith | Microservices |
| :--- | :--- | :--- | :--- |
| Chi phí Hạ tầng | Cực thấp (1 VPS) | Cực thấp (1 VPS) | Rất đắt (K8s, Gateway) |
| Ranh giới Nghiệp vụ | Yếu (Dễ vỡ) | Rất mạnh (ArchUnit) | Rất mạnh (Network) |
| Độ trễ giao tiếp | < 1ms | < 1ms (In-Memory) | 20-80ms (Network hop) |
| Giao dịch CSDL | ACID dễ dàng | ACID nội bộ + Event | Phức tạp (Saga/2PC) |
| Tốc độ Debug | Dễ dàng | 1-Click Debug | Cần Distributed Tracing |
| Khả năng tách dịch vụ | Bất khả thi | Dễ dàng (Vài ngày) | Vốn đã phân tán |

---
*Tài liệu tự động xuất từ LibModular - Hệ thống Nghiên cứu Kiến trúc Phần mềm.*
`;

    const blob = new Blob([reportContent], { type: 'text/markdown;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'BaoCao_Modular_Monolith_ThuVien.md');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredQuestions =
    selectedCategory === 'All'
      ? DEFENSE_QUESTIONS
      : DEFENSE_QUESTIONS.filter((q) => q.category === selectedCategory);

  const currentSlide = SLIDES[currentSlideIndex];

  return (
    <div className="space-y-6">
      {/* Editorial Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-sky-400 mb-1.5">
            <span className="px-2.5 py-0.5 rounded-full bg-sky-500/15 border border-sky-500/30 text-sky-300">
              Học Liệu & Đánh Giá
            </span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="text-slate-300">Bảo Vệ Đồ Án Môn Học</span>
            <span aria-hidden="true" className="text-slate-500">·</span>
            <span className="text-slate-300">Slide & Câu Hỏi Phản Biện</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-snug">
            Hồ Sơ Bảo Vệ Đồ Án: Các Vấn Đề Hiện Đại Của CNTT
          </h2>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => {
              soundFX.playClick();
              setIsPresentationOpen(true);
              setIsTimerRunning(true);
            }}
            className="px-4 py-2.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-md shadow-sky-600/25 flex items-center gap-2"
          >
            <Maximize2 className="w-4 h-4" />
            <span>Chế Độ Thuyết Trình Hội Đồng</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={handleExportMarkdown}
            className="px-4 py-2.5 text-xs font-semibold text-slate-200 bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 rounded-xl transition-all shadow-md flex items-center gap-2 backdrop-blur-xs"
          >
            <Download className="w-4 h-4 text-sky-400" />
            <span>Tải Báo Cáo (.MD)</span>
          </motion.button>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/80 rounded-xl w-fit border border-slate-700/80 backdrop-blur-md">
        <button
          onClick={() => {
            soundFX.playSwitch();
            setActiveTab('slides');
          }}
          className={`flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${
            activeTab === 'slides'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30 font-semibold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>1. Slide Trình Bày (Defense Deck)</span>
        </button>

        <button
          onClick={() => {
            soundFX.playSwitch();
            setActiveTab('qa');
          }}
          className={`flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${
            activeTab === 'qa'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30 font-semibold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <HelpCircle className="w-3.5 h-3.5" />
          <span>2. Câu Hỏi Phản Biện & Lời Giải Mẫu</span>
        </button>

        <button
          onClick={() => {
            soundFX.playSwitch();
            setActiveTab('matrix');
          }}
          className={`flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${
            activeTab === 'matrix'
              ? 'bg-sky-600 text-white shadow-md shadow-sky-600/30 font-semibold'
              : 'text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          <Table className="w-3.5 h-3.5" />
          <span>3. Ma Trận Đánh Đổi 8 Tiêu Chí</span>
        </button>
      </div>

      {/* 1. SLIDES TAB */}
      {activeTab === 'slides' && (
        <div className="space-y-4">
          <div className="bg-slate-950/90 text-slate-100 rounded-2xl border border-slate-700/80 shadow-2xl p-6 sm:p-8 space-y-6 backdrop-blur-md">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div className="space-y-1">
                <div className="text-xs font-mono text-sky-400 font-semibold">
                  SLIDE {currentSlideIndex + 1} / {SLIDES.length} · BẢO VỆ ĐỒ ÁN CNTT
                </div>
                <h3 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-snug">
                  {currentSlide.title}
                </h3>
                <div className="text-sm text-slate-400 mt-0.5 leading-normal">{currentSlide.subtitle}</div>
              </div>

              <button
                onClick={() => {
                  soundFX.playClick();
                  setIsPresentationOpen(true);
                  setIsTimerRunning(true);
                }}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
                title="Mở toàn màn hình để thuyết trình"
              >
                <Maximize2 className="w-3.5 h-3.5" />
                <span>Toàn màn hình</span>
              </button>
            </div>

            <div className="space-y-3.5 pt-2">
              {currentSlide.bullets.map((bullet, idx) => (
                <div key={idx} className="flex items-start gap-3.5 text-sm sm:text-base text-slate-200 leading-relaxed font-normal">
                  <div className="w-6 h-6 rounded-full bg-sky-950 border border-sky-500/50 text-sky-300 flex items-center justify-center text-xs font-mono font-bold shrink-0 mt-0.5">
                    {idx + 1}
                  </div>
                  <div>{bullet}</div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-sky-950/60 border border-sky-800/80 rounded-xl text-xs sm:text-sm text-sky-200 flex items-start gap-3 leading-relaxed">
              <Star className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="font-bold text-white">Thông điệp cốt lõi: </strong>
                <span>{currentSlide.keyTakeaway}</span>
              </div>
            </div>

            {/* Slide Navigation Controls */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-800">
              <button
                onClick={handlePrevSlide}
                disabled={currentSlideIndex === 0}
                className="px-4 py-2 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-colors disabled:opacity-40 flex items-center gap-1.5"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Slide trước</span>
              </button>

              <div className="flex items-center gap-1.5">
                {SLIDES.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      soundFX.playClick();
                      setCurrentSlideIndex(idx);
                    }}
                    className={`h-2.5 rounded-full transition-all ${
                      idx === currentSlideIndex ? 'bg-sky-400 w-7' : 'bg-slate-700 hover:bg-slate-600 w-2.5'
                    }`}
                    title={`Chuyển tới slide ${idx + 1}`}
                  />
                ))}
              </div>

              <button
                onClick={handleNextSlide}
                disabled={currentSlideIndex === SLIDES.length - 1}
                className="px-4 py-2 text-xs font-semibold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-colors disabled:opacity-40 flex items-center gap-1.5 shadow-md shadow-sky-600/25"
              >
                <span>Slide tiếp theo</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 2. DEFENSE QUESTIONS & ANSWERS TAB */}
      {activeTab === 'qa' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/80 rounded-xl w-fit border border-slate-700/80 backdrop-blur-md text-xs">
            {(['All', 'LyThuyet', 'ThietKe', 'HieuNang', 'TrienKhai'] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => {
                  soundFX.playClick();
                  setSelectedCategory(cat);
                }}
                className={`px-3 py-1.5 rounded-lg transition-colors font-medium ${
                  selectedCategory === cat
                    ? 'bg-sky-600 text-white font-semibold shadow-xs'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat === 'All'
                  ? 'Tất cả câu hỏi'
                  : cat === 'LyThuyet'
                  ? 'Lý thuyết'
                  : cat === 'ThietKe'
                  ? 'Thiết kế'
                  : cat === 'HieuNang'
                  ? 'Hiệu năng'
                  : 'Triển khai'}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredQuestions.map((q) => {
              const isExpanded = expandedQuestionId === q.id;
              return (
                <div
                  key={q.id}
                  className="bg-slate-900/85 backdrop-blur-md border border-slate-700/80 rounded-2xl overflow-hidden shadow-lg transition-all"
                >
                  <button
                    onClick={() => {
                      soundFX.playClick();
                      setExpandedQuestionId(isExpanded ? null : q.id);
                    }}
                    className="w-full text-left p-4 sm:p-5 flex items-start justify-between gap-4 hover:bg-slate-800/60 transition-colors"
                  >
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-mono text-sky-400 font-bold">{q.id.toUpperCase()}</span>
                        <span className="text-slate-500">·</span>
                        <span className="text-slate-400 font-medium">
                          {q.category === 'LyThuyet'
                            ? 'Lý thuyết kiến trúc'
                            : q.category === 'ThietKe'
                            ? 'Thiết kế chi tiết'
                            : q.category === 'HieuNang'
                            ? 'Hiệu năng & Khóa'
                            : 'Triển khai'}
                        </span>
                        <span className="text-slate-500">·</span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-mono border ${
                            q.difficulty === 'ChuyenSau'
                              ? 'bg-purple-950/80 border-purple-500/40 text-purple-300'
                              : q.difficulty === 'NangCao'
                              ? 'bg-amber-950/80 border-amber-500/40 text-amber-300'
                              : 'bg-sky-950/80 border-sky-500/40 text-sky-300'
                          }`}
                        >
                          {q.difficulty}
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-white leading-snug">
                        {q.question}
                      </h4>
                    </div>

                    <div className="text-slate-400 mt-1 shrink-0">
                      <ChevronRight
                        className={`w-5 h-5 transition-transform duration-200 ${
                          isExpanded ? 'rotate-90 text-sky-400' : ''
                        }`}
                      />
                    </div>
                  </button>

                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      className="p-5 pt-0 border-t border-slate-800 space-y-4 text-xs sm:text-sm"
                    >
                      {/* Lecturer Perspective */}
                      <div className="p-3.5 bg-amber-950/40 border border-amber-500/30 rounded-xl text-amber-200 space-y-1 leading-relaxed">
                        <div className="font-bold flex items-center gap-1.5 text-amber-300">
                          <HelpCircle className="w-4 h-4 text-amber-400 shrink-0" />
                          <span>Mục đích đánh giá của Giảng viên:</span>
                        </div>
                        <div className="text-slate-300 font-normal">{q.lecturerPerspective}</div>
                      </div>

                      {/* Model Answer */}
                      <div className="space-y-2">
                        <div className="font-bold text-white flex items-center gap-2 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                          <span>Câu trả lời chuẩn đạt điểm tối đa (Model Answer):</span>
                        </div>
                        <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl text-slate-200 whitespace-pre-line leading-relaxed font-normal">
                          {q.modelAnswer}
                        </div>
                      </div>

                      {/* Key Terminology */}
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <span className="font-semibold text-slate-400 text-xs">Từ khóa ghi điểm:</span>
                        {q.keyTerminology.map((term, idx) => (
                          <span
                            key={idx}
                            className="font-mono text-[11px] bg-slate-800 text-sky-300 px-2.5 py-0.5 rounded-full border border-slate-700"
                          >
                            {term}
                          </span>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 3. TRADEOFF MATRIX TAB */}
      {activeTab === 'matrix' && (
        <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden text-white">
          <div className="p-5 border-b border-slate-800">
            <h3 className="text-base sm:text-lg font-bold text-white leading-snug">
              Bảng Đánh Đổi Toàn Diện: 3 Mô Hình Kiến Trúc Phần Mềm
            </h3>
            <p className="text-xs text-slate-400 mt-1 leading-normal">
              So sánh khách quan dựa trên tiêu chuẩn công nghiệp và kinh nghiệm triển khai thực tế
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-slate-950/80 text-slate-300 border-b border-slate-800">
                <tr>
                  <th className="py-3.5 px-4 font-bold w-1/4">Tiêu Chí Đánh Giá</th>
                  <th className="py-3.5 px-4 font-bold w-1/4 text-rose-400">Monolith Truyền Thống</th>
                  <th className="py-3.5 px-4 font-bold w-1/4 text-sky-400 bg-sky-950/40">
                    Modular Monolith (Đồ Án)
                  </th>
                  <th className="py-3.5 px-4 font-bold w-1/4 text-purple-400">Microservices</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 text-slate-300">
                {ARCHITECTURE_METRICS.map((metric, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/50 transition-colors">
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-white leading-snug">{metric.criterion}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5 leading-normal">{metric.note}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 align-top leading-relaxed">
                      <div>{metric.traditionalMonolith.description}</div>
                    </td>
                    <td className="py-3.5 px-4 bg-sky-950/20 text-slate-200 align-top leading-relaxed">
                      <div className="font-semibold text-white">{metric.modularMonolith.description}</div>
                    </td>
                    <td className="py-3.5 px-4 text-slate-300 align-top leading-relaxed">
                      <div>{metric.microservices.description}</div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Fullscreen Academic Presentation Deck Modal */}
      <AnimatePresence>
        {isPresentationOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-slate-950 flex flex-col text-slate-100 p-6 sm:p-10"
          >
            {/* Presentation Top Bar */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400">
                  <Award className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-xs font-mono text-sky-400 font-bold uppercase">
                    Hội Đồng Bảo Vệ Đồ Án CNTT Hiện Đại
                  </div>
                  <div className="text-sm font-semibold text-white">
                    Kiến Trúc Modular Monolith - Hệ Thống Quản Lý Thư Viện Đại Học
                  </div>
                </div>
              </div>

              {/* Timer and Exit Controls */}
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-mono">
                  <Clock className="w-3.5 h-3.5 text-sky-400" />
                  <span className="text-white font-bold">{formatTimer(presentationSeconds)}</span>
                  <button
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                    className="p-1 hover:text-sky-400 text-slate-400"
                    title={isTimerRunning ? 'Tạm dừng đồng hồ' : 'Tiếp tục tính giờ'}
                  >
                    {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                  </button>
                </div>

                <button
                  onClick={() => setIsPresentationOpen(false)}
                  className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors flex items-center gap-1.5 text-xs"
                  title="Thoát chế độ thuyết trình (ESC)"
                >
                  <Minimize2 className="w-4 h-4" />
                  <span className="hidden sm:inline">Thoát (ESC)</span>
                </button>
              </div>
            </div>

            {/* Main Presentation Slide Viewport */}
            <div className="flex-1 flex flex-col justify-between max-w-5xl mx-auto w-full py-4 space-y-6">
              <div className="space-y-4">
                <div className="text-sm font-mono text-sky-400 font-semibold">
                  SLIDE {currentSlideIndex + 1} / {SLIDES.length}
                </div>
                <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
                  {currentSlide.title}
                </h1>
                <p className="text-base sm:text-lg text-slate-400 font-medium leading-relaxed">
                  {currentSlide.subtitle}
                </p>

                <div className="space-y-4 pt-4">
                  {currentSlide.bullets.map((bullet, idx) => (
                    <div key={idx} className="flex items-start gap-4 text-base sm:text-lg text-slate-200 leading-relaxed">
                      <div className="w-7 h-7 rounded-full bg-sky-950 border border-sky-500 text-sky-300 flex items-center justify-center text-sm font-mono font-bold shrink-0 mt-0.5">
                        {idx + 1}
                      </div>
                      <div>{bullet}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom Key Takeaway Callout */}
              <div className="p-5 bg-sky-950/70 border border-sky-600/60 rounded-2xl text-sm sm:text-base text-sky-200 flex items-start gap-3.5 shadow-xl">
                <Star className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="font-bold text-white text-base">Thông Điệp Cốt Lõi Cho Hội Đồng: </strong>
                  <span>{currentSlide.keyTakeaway}</span>
                </div>
              </div>
            </div>

            {/* Presentation Bottom Navigation */}
            <div className="flex items-center justify-between border-t border-slate-800 pt-4 mt-4 max-w-5xl mx-auto w-full">
              <button
                onClick={handlePrevSlide}
                disabled={currentSlideIndex === 0}
                className="px-5 py-2.5 text-sm font-semibold text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-xl transition-colors disabled:opacity-30 flex items-center gap-2"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Slide Trước (←)</span>
              </button>

              <div className="flex items-center gap-2">
                {SLIDES.map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      soundFX.playClick();
                      setCurrentSlideIndex(idx);
                    }}
                    className={`h-3 rounded-full transition-all ${
                      idx === currentSlideIndex ? 'bg-sky-400 w-8' : 'bg-slate-700 hover:bg-slate-600 w-3'
                    }`}
                  />
                ))}
              </div>

              <button
                onClick={handleNextSlide}
                disabled={currentSlideIndex === SLIDES.length - 1}
                className="px-5 py-2.5 text-sm font-bold text-white bg-sky-600 hover:bg-sky-500 rounded-xl transition-all shadow-md shadow-sky-600/30 disabled:opacity-30 flex items-center gap-2"
              >
                <span>Slide Kế Tiếp (→ / Space)</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
