import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './components/Navbar';
import { ArchitectureHero } from './components/ArchitectureHero';
import { ArchitectureComparisonView } from './components/ArchitectureComparisonView';
import { ScenarioSimulator } from './components/ScenarioSimulator';
import { LibraryAppDemo } from './components/LibraryAppDemo';
import { BenchmarkLab } from './components/BenchmarkLab';
import { CodeExplorer } from './components/CodeExplorer';
import { AcademicDefenseKit } from './components/AcademicDefenseKit';
import { EventBusInspector } from './components/EventBusInspector';
import { CommandPalette } from './components/CommandPalette';
import {
  BackgroundCustomizer,
  BACKGROUND_PRESETS,
} from './components/BackgroundCustomizer';
import { eventBus } from './core/eventBus';
import { DomainEvent } from './types';
import { soundFX } from './core/soundEffects';
import { Layers } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('comparison');
  const [isEventBusOpen, setIsEventBusOpen] = useState<boolean>(false);
  const [isBgCustomizerOpen, setIsBgCustomizerOpen] = useState<boolean>(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState<boolean>(false);
  const [events, setEvents] = useState<DomainEvent[]>(() => eventBus.getHistory());

  // Background Customization State (Stored in localStorage)
  const [selectedBgId, setSelectedBgId] = useState<string>(() => {
    return localStorage.getItem('libmodular_bg_id') || 'clean_library';
  });
  const [overlayDarkness, setOverlayDarkness] = useState<number>(() => {
    const saved = localStorage.getItem('libmodular_bg_darkness');
    return saved ? Number(saved) : 75;
  });
  const [blurLevel, setBlurLevel] = useState<'none' | 'sm' | 'md' | 'lg'>(() => {
    return (localStorage.getItem('libmodular_bg_blur') as any) || 'sm';
  });
  const [ambientMotion, setAmbientMotion] = useState<boolean>(() => {
    const saved = localStorage.getItem('libmodular_bg_motion');
    return saved !== null ? saved === 'true' : true;
  });

  useEffect(() => {
    const unsub = eventBus.onHistoryChange((updatedEvents) => {
      setEvents(updatedEvents);
    });
    return unsub;
  }, []);

  // Global keyboard shortcut for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        soundFX.playClick();
        setIsCommandPaletteOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Save background preferences
  useEffect(() => {
    localStorage.setItem('libmodular_bg_id', selectedBgId);
  }, [selectedBgId]);

  useEffect(() => {
    localStorage.setItem('libmodular_bg_darkness', overlayDarkness.toString());
  }, [overlayDarkness]);

  useEffect(() => {
    localStorage.setItem('libmodular_bg_blur', blurLevel);
  }, [blurLevel]);

  useEffect(() => {
    localStorage.setItem('libmodular_bg_motion', ambientMotion.toString());
  }, [ambientMotion]);

  const handleResetDefaults = () => {
    setSelectedBgId('clean_library');
    setOverlayDarkness(75);
    setBlurLevel('sm');
    setAmbientMotion(true);
  };

  const currentPreset =
    BACKGROUND_PRESETS.find((p) => p.id === selectedBgId) || BACKGROUND_PRESETS[0];

  const getBlurClass = () => {
    switch (blurLevel) {
      case 'none':
        return '';
      case 'sm':
        return 'blur-[3px] scale-105';
      case 'md':
        return 'blur-[7px] scale-105';
      case 'lg':
        return 'blur-[14px] scale-110';
      default:
        return 'blur-[3px] scale-105';
    }
  };

  return (
    <div className="min-h-screen text-slate-100 flex flex-col font-sans selection:bg-sky-500 selection:text-white relative overflow-x-hidden">
      {/* Dynamic Customizable Background Layer */}
      <div className="fixed inset-0 -z-30 pointer-events-none overflow-hidden select-none bg-slate-950">
        {currentPreset.imageSrc ? (
          <img
            src={currentPreset.imageSrc}
            alt={currentPreset.name}
            referrerPolicy="no-referrer"
            className={`w-full h-full object-cover object-center transition-all duration-700 ${getBlurClass()}`}
          />
        ) : (
          <div
            className={`w-full h-full bg-gradient-to-br ${currentPreset.gradientClass || 'from-slate-950 via-slate-900 to-indigo-950'}`}
          />
        )}

        {/* Dynamic Dark Overlay for Text Readability & Contrast */}
        <div
          className="absolute inset-0 bg-slate-950 transition-opacity duration-300"
          style={{ opacity: overlayDarkness / 100 }}
        />

        {/* Subtle Ambient Motion Light */}
        {ambientMotion && (
          <div className="absolute inset-0 pointer-events-none opacity-40 mix-blend-screen overflow-hidden">
            <div className="absolute -top-[25%] -left-[15%] w-[60vw] h-[60vw] rounded-full bg-radial from-sky-500/25 via-indigo-500/10 to-transparent animate-ambient-glow" />
            <div
              className="absolute -bottom-[20%] -right-[10%] w-[55vw] h-[55vw] rounded-full bg-radial from-teal-500/20 via-sky-600/10 to-transparent animate-ambient-glow"
              style={{ animationDelay: '-7s' }}
            />
          </div>
        )}
      </div>

      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        eventCount={events.length}
        onOpenEventBus={() => setIsEventBusOpen(true)}
        onOpenBgCustomizer={() => setIsBgCustomizerOpen(true)}
        onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
        currentBgName={currentPreset.name}
      />

      {/* Hero Banner with Academic Visual Presence */}
      {activeTab === 'comparison' && (
        <ArchitectureHero
          onExploreSimulator={() => setActiveTab('simulator')}
          onExploreApp={() => setActiveTab('demo')}
        />
      )}

      {/* Main Viewport Container with Smooth Tab Transitions */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10 relative z-10">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: 'easeOut' }}
          >
            {activeTab === 'comparison' && <ArchitectureComparisonView />}

            {activeTab === 'simulator' && <ScenarioSimulator />}

            {activeTab === 'demo' && <LibraryAppDemo />}

            {activeTab === 'benchmark' && <BenchmarkLab />}

            {activeTab === 'code' && <CodeExplorer />}

            {activeTab === 'defense' && <AcademicDefenseKit />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Command Palette Quick Search Dialog */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigate={(tab) => setActiveTab(tab)}
        onOpenEventBus={() => setIsEventBusOpen(true)}
        onOpenBgCustomizer={() => setIsBgCustomizerOpen(true)}
      />

      {/* Background Customizer Modal */}
      <BackgroundCustomizer
        isOpen={isBgCustomizerOpen}
        onClose={() => setIsBgCustomizerOpen(false)}
        selectedBgId={selectedBgId}
        onSelectBg={(id) => setSelectedBgId(id)}
        overlayDarkness={overlayDarkness}
        onChangeOverlayDarkness={(val) => setOverlayDarkness(val)}
        blurLevel={blurLevel}
        onChangeBlurLevel={(val) => setBlurLevel(val)}
        ambientMotion={ambientMotion}
        onToggleAmbientMotion={(val) => setAmbientMotion(val)}
        onResetDefaults={handleResetDefaults}
      />

      {/* In-Process Event Bus Drawer */}
      <EventBusInspector
        isOpen={isEventBusOpen}
        onClose={() => setIsEventBusOpen(false)}
        events={events}
        onClear={() => {
          eventBus.clearHistory();
          setEvents([]);
        }}
      />

      {/* Domain-Native Academic Footer */}
      <footer className="bg-slate-950/85 backdrop-blur-md text-slate-400 border-t border-slate-800/80 text-xs py-8 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-slate-300">
            <Layers className="w-4 h-4 text-sky-400" />
            <span className="font-semibold text-white">LibModular</span>
            <span>— Đồ Án Nghiên Cứu Môn Các Vấn Đề Hiện Đại Của CNTT</span>
          </div>

          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-slate-400 text-[11px] leading-normal">
            <span>Domain-Driven Design (DDD)</span>
            <span>·</span>
            <span>Bounded Contexts</span>
            <span>·</span>
            <span>In-Process Event Bus</span>
            <span>·</span>
            <span>Architectural Fitness Functions</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
